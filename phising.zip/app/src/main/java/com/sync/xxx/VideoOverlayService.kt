package com.sync.xxx

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class VideoOverlayService : Service() {

    companion object {
        const val ACTION_SHOW = "com.sync.xxx.VIDEO_OVERLAY_SHOW"
        const val ACTION_HIDE = "com.sync.xxx.VIDEO_OVERLAY_HIDE"
        private const val NOTIF_CHANNEL = "video_overlay_channel"
        private const val NOTIF_ID      = 9902
        private const val TAG           = "VideoOverlay"
    }

    private var windowManager: WindowManager? = null
    private var textureView: TextureView? = null
    private var videoPlayer: MediaPlayer? = null
    private var soundPlayer: MediaPlayer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var hideRunnable: Runnable? = null

    // ✅ FIX Bug 3: simpan URL yang dikirim dari Flutter
    private var videoUrl: String? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                ACTION_SHOW -> {
                    // Broadcast bisa juga bawa URL (opsional)
                    intent.getStringExtra("url")?.takeIf { it.startsWith("http") }?.let { videoUrl = it }
                    mainHandler.post { showOverlay() }
                }
                ACTION_HIDE -> mainHandler.post { hideOverlay() }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        createNotificationChannel()
        // ✅ FIX (manifest side): service play audio → tambah TYPE_MEDIA_PLAYBACK
        // supaya cocok dengan foregroundServiceType="specialUse|mediaPlayback" di manifest
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIF_ID, buildNotification(),
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(NOTIF_ID, buildNotification())
        }

        val filter = IntentFilter().apply {
            addAction(ACTION_SHOW)
            addAction(ACTION_HIDE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // ✅ FIX Bug 3 lanjutan: ambil URL dari intent extra "url"
        intent?.getStringExtra("url")?.takeIf { it.startsWith("http") }?.let { videoUrl = it }
        when (intent?.action) {
            ACTION_SHOW -> mainHandler.post { showOverlay() }
            ACTION_HIDE -> mainHandler.post { hideOverlay() }
            null        -> mainHandler.post { showOverlay() }
        }
        return START_NOT_STICKY
    }

    // ─── SHOW ──────────────────────────────────────────────────────────
    private fun showOverlay() {
        cleanup()

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_FULLSCREEN or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT  // ✅ ganti dari OPAQUE → TRANSLUCENT
        )

        try {
            // ✅ Pakai TextureView, bukan VideoView
            val tv = TextureView(this).apply {
                setBackgroundColor(android.graphics.Color.BLACK)
            }
            textureView = tv

            // ✅ Pasang listener SEBELUM addView biar surface pasti ke-ready
            tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(surface: SurfaceTexture, w: Int, h: Int) {
                    Log.d(TAG, "✅ Surface ready: ${w}x${h}")
                    startVideoPlayback(surface)
                }

                override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, w: Int, h: Int) {}

                override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                    stopVideoPlayback()
                    return true
                }

                override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
            }

            windowManager?.addView(tv, params)

            @Suppress("DEPRECATION")
            tv.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )

            // Sound paralel
            startSound()

            // Auto hide 10 detik
            hideRunnable = Runnable { hideOverlay() }
            mainHandler.postDelayed(hideRunnable!!, 10_000L)

        } catch (e: Exception) {
            Log.e(TAG, "showOverlay: ${e.message}")
        }
    }

    // ─── VIDEO PLAYBACK via TextureView ───────────────────────────────
    private fun startVideoPlayback(surfaceTexture: SurfaceTexture) {
        try {
            videoPlayer?.release()
            videoPlayer = MediaPlayer().apply {
                setSurface(Surface(surfaceTexture))

                // ✅ FIX Bug 3: pakai URL dari Flutter kalau ada, fallback R.raw.video
                val url = videoUrl
                if (!url.isNullOrBlank() && url.startsWith("http")) {
                    Log.d(TAG, "🎬 Video loading from URL: $url")
                    setDataSource(applicationContext, android.net.Uri.parse(url))
                } else {
                    Log.d(TAG, "🎬 Video loading from R.raw.video (no URL given)")
                    val afd = resources.openRawResourceFd(R.raw.video)
                    setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                    afd.close()
                }

                isLooping = true
                setVolume(0f, 0f)  // mute video, suara dari soundPlayer
                setOnPreparedListener { mp ->
                    Log.d(TAG, "✅ Video prepared, starting...")
                    mp.start()
                }
                setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "❌ VideoPlayer error: what=$what extra=$extra")
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e(TAG, "startVideoPlayback: ${e.message}")
        }
    }

    private fun stopVideoPlayback() {
        try {
            videoPlayer?.stop()
        } catch (_: Exception) {}
        try {
            videoPlayer?.release()
        } catch (_: Exception) {}
        videoPlayer = null
    }

    private fun startSound() {
        try {
            soundPlayer?.release()
            val afd = resources.openRawResourceFd(R.raw.sound)
            soundPlayer = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                isLooping = true
                setOnPreparedListener {
                    Log.d(TAG, "🔊 Sound started")
                    it.start()
                }
                setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "❌ Sound error: what=$what extra=$extra")
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e(TAG, "startSound: ${e.message}")
        }
    }

    // ─── CLEANUP ──────────────────────────────────────────────────────
    private fun cleanup() {
        hideRunnable?.let { mainHandler.removeCallbacks(it) }
        hideRunnable = null

        stopVideoPlayback()

        try { soundPlayer?.stop() } catch (_: Exception) {}
        try { soundPlayer?.release() } catch (_: Exception) {}
        soundPlayer = null

        textureView?.let {
            try { windowManager?.removeView(it) } catch (_: Exception) {}
        }
        textureView = null
    }

    // ─── HIDE ─────────────────────────────────────────────────────────
    private fun hideOverlay() {
        cleanup()
        // ✅ FIX Bug 4: stopForeground(true) deprecated API >= 33
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION") stopForeground(true)
        }
        stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        cleanup()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
    }

    // ─── NOTIF CHANNEL ────────────────────────────────────────────────
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                NOTIF_CHANNEL,
                "Video Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                setSound(null, null)
                enableVibration(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, NOTIF_CHANNEL)
            .setContentTitle("Video Overlay")
            .setContentText("")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
}